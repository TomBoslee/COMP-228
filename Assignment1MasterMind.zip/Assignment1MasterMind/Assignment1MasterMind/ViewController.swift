//
//  ViewController.swift
//  Assignment1MasterMind
//
//  Created by Carruthers, Thomas on 29/10/2021.
//

import UIKit
var Guesses = 1
var CurrentRound = [String]()
var GameRound = [[String]]()
var Solution = [String]()

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Guesses
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as! MastermindTableViewCell
        var Round = [String]()
        if (indexPath.row == GameRound.count){
            cell.ImageView1.image = nil
            cell.ImageView2.image = nil
            cell.ImageView3.image = nil
            cell.ImageView4.image = nil
            cell.ImageView5.image = nil
            cell.ImageView6.image = nil
            cell.ImageView7.image = nil
            cell.ImageView8.image = nil
            if (CurrentRound.count > 0){
                cell.ImageView1.image=UIImage(named: CurrentRound[0])
            }
            if (CurrentRound.count > 1){
                cell.ImageView2.image=UIImage(named: CurrentRound[1])
            }
            if (CurrentRound.count > 2){
                cell.ImageView3.image=UIImage(named: CurrentRound[2])
            }
            if (CurrentRound.count > 3){
                cell.ImageView4.image=UIImage(named: CurrentRound[3])
            }
        }
        else if (GameRound.count > 0){
            Round = GameRound[indexPath.row]
            cell.ImageView1.image=UIImage(named: Round[0])
            cell.ImageView2.image=UIImage(named: Round[1])
            cell.ImageView3.image=UIImage(named: Round[2])
            cell.ImageView4.image=UIImage(named: Round[3])
            cell.ImageView5.image=UIImage(named: Round[4])
            cell.ImageView6.image=UIImage(named: Round[5])
            cell.ImageView7.image=UIImage(named: Round[6])
            cell.ImageView8.image=UIImage(named: Round[7])
        }
        return cell
    }
    
    @IBAction func ImageButton1(_ sender: Any) {
        if (CurrentRound.count < 4){
            CurrentRound.append("blue")
            TableView.reloadData()

        }
    }
    
    @IBAction func ImageButton2(_ sender: Any) {
        if (CurrentRound.count < 4){
            CurrentRound.append("yellow")
            TableView.reloadData()

        }
    }
    
    @IBAction func ImageButton3(_ sender: Any) {
        if (CurrentRound.count < 4){
            CurrentRound.append("green")
            TableView.reloadData()

        }
    }
    
    @IBAction func ImageButton4(_ sender: Any) {
        if (CurrentRound.count < 4){
            CurrentRound.append("red")
            TableView.reloadData()

        }
    }
    
    @IBAction func ImageButton5(_ sender: Any) {
        if (CurrentRound.count < 4){
            CurrentRound.append("grey")
            TableView.reloadData()

        }
    }
    
    @IBAction func ImageButton6(_ sender: Any) {
        if (CurrentRound.count < 4){
            CurrentRound.append("orange")
            TableView.reloadData()

        }
    }
    
    @IBAction func DeleteButton(_ sender: Any) {
        if (CurrentRound.count > 0){
            CurrentRound.removeLast()
            TableView.reloadData()

        }
    }
    
    @IBAction func OkButton(_ sender: Any) {
        if (CurrentRound.count == 4 && Guesses < 11){
            Guesses = Guesses + 1
            for n in 0...3 {
                if (Solution[n] == CurrentRound[n]){
                    CurrentRound.append("black blob")
                }
                else if (Solution.contains(CurrentRound[n])){
                    CurrentRound.append("white blob")
                }
                else{
                    CurrentRound.append("empty")
                }
            }
            GameRound.append(CurrentRound)
            CurrentRound.removeAll()
            TableView.reloadData()
        }
    }
    
    @IBOutlet weak var TableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let Colours = ["red", "blue","orange","yellow","grey","green"]
        var num = Int()
        for _ in 1...4 {
            num = Int.random(in: 0..<6)
            Solution.append(Colours[num])
        }
    }
    

}

