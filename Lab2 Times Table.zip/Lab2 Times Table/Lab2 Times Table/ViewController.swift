//
//  ViewController.swift
//  Lab2 Times Table
//
//  Created by Carruthers, Thomas on 15/10/2021.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var num:Int = 0
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 40
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let MyCell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "myCell")
        let value:Int = indexPath.row + 1
        let ans:Int = value * num
        MyCell.textLabel!.text = "\(num) * \(value) = \(ans)"
        return MyCell
    }
    

    @IBAction func OkButton(_ sender: Any) {
        num = Int(InputField.text!)!
        InputField.resignFirstResponder()
        TableView.isHidden = false
        TableView.reloadData()
    }
    
    @IBOutlet weak var TableView: UITableView!
    @IBOutlet weak var InputField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

