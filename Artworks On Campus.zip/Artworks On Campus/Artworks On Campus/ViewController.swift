//
//  ViewController.swift
//  Artworks On Campus
//
//  Created by Carruthers, Thomas on 26/11/2021.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MKMapViewDelegate,
CLLocationManagerDelegate {
     
    var locationManager = CLLocationManager()
     
    var firstRun = true
    var startTrackingTheUser = false

    @IBOutlet weak var myMap: MKMapView!
    
    @IBOutlet weak var myTable: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return 1
       }
        
        
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle, reuseIdentifier: "myCell")
           cell.textLabel?.text = "testing"
           cell.detailTextLabel?.text = "more testing"
           return cell
       }
        
        
       override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view, typically from a nib.
           locationManager.delegate = self as CLLocationManagerDelegate
           locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
           locationManager.requestWhenInUseAuthorization()
           locationManager.startUpdatingLocation()
           myMap.showsUserLocation = true
       }
        
       func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            
           let locationOfUser = locations[0]
           let latitude = locationOfUser.coordinate.latitude
           let longitude = locationOfUser.coordinate.longitude
           let location = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
            
           if firstRun {
               firstRun = false
               let latDelta: CLLocationDegrees = 0.0025
               let lonDelta: CLLocationDegrees = 0.0025
               let span = MKCoordinateSpan(latitudeDelta: latDelta, longitudeDelta: lonDelta)
               let region = MKCoordinateRegion(center: location, span: span)
               self.myMap.setRegion(region, animated: true)
                
               //the following code is to prevent a bug which affects the zooming of the map to the user's location.
               //We have to leave a little time after our initial setting of the map's location and span,
               //before we can start centering on the user's location, otherwise the map never zooms in because the
               //intial zoom level and span are applied to the setCenter() method call, rather than our "requested"
               //ones, once they have taken effect on the map.
               //we setup a timer to set our boolean to true in 5 seconds.
               _ = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(startUserTracking),
   userInfo: nil, repeats: false)
           }
           if startTrackingTheUser == true {
               myMap.setCenter(location, animated: true)
           }
              }
               
              //this method sets the startTrackingTheUser boolean class property to true. Once it's true, subsequent calls
              //to didUpdateLocations will cause the map to center on the user's location.
              @objc func startUserTracking() {
                  startTrackingTheUser = true
              }
}

