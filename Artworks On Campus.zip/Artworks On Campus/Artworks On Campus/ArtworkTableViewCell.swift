//
//  ArtworkTableViewCell.swift
//  Artworks On Campus
//
//  Created by Carruthers, Thomas on 26/11/2021.
//

import UIKit

class ArtworkTableViewCell: UITableViewCell {

    
    @IBOutlet weak var ArtworkImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    

}

