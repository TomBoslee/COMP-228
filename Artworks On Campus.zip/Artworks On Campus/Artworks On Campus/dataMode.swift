//
//  dataMode.swift
//  Artworks On Campus
//
//  Created by Carruthers, Thomas on 03/12/2021.
//

import Foundation
