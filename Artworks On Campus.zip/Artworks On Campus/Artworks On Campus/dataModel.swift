//
//  dataModel.swift
//  Artworks On Campus
//
//  Created by Carruthers, Thomas on 03/12/2021.
//

import Foundation

struct ArtworkReport: Decodable{
    let id:String
    let title:String
    let artist:String
    let yearOfWork:String?
    let type:String?
    let Information:String?
    let lat:String
    let long: String
    let location:String?
    let locationNotes:String?
    let ImagefileName:String?
    let thumbnail:URL?
    let lastModified:String
    let enabled:String
}

struct ArtworkOnCampusReports: Decodable {
    let campusart: [ArtworkReport]
}
