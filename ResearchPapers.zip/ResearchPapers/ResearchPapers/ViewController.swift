//
//  ViewController.swift
//  ResearchPapers
//
//  Created by Carruthers, Thomas on 26/11/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var TitleLabel: UILabel!
    
    @IBOutlet weak var AuthorLabel: UILabel!
    
    @IBOutlet weak var YearLabel: UILabel!
    
    @IBOutlet weak var EmailLabel: UILabel!
    
    @IBOutlet weak var UrlTextField: UITextView!
    
    @IBOutlet weak var AbstractTextField: UITextView!
    var Title:String
    var Author:String
    var Year:Int
    var Email:String
    var Abstract:String
    var Url:String
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

