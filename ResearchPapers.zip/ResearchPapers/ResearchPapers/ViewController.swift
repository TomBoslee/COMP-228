//
//  ViewController.swift
//  ResearchPapers
//
//  Created by Carruthers, Thomas on 26/11/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var TitleLabel: UILabel!
    
    @IBOutlet weak var AuthorLabel: UILabel!
    
    @IBOutlet weak var YearLabel: UILabel!
    
    @IBOutlet weak var EmailLabel: UILabel!
    
    @IBOutlet weak var UrlTextField: UITextView!
    
    @IBOutlet weak var AbstractTextField: UITextView!
    var Title:String = ""
    var Author:String = ""
    var Year:String = ""
    var Email:String = ""
    var Abstract:String = ""
    var Url:URL?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        TitleLabel.text = "Title: " + Title
        AuthorLabel.text = "Author: " + Author
        YearLabel.text = "Year: \(Year)"
        EmailLabel.text = "Email: " + Email
        AbstractTextField.text = Abstract
        let attributedString = NSMutableAttributedString(string: "Just click here to open PDF")

        // Set the 'click here' substring to be the link
        attributedString.setAttributes([.link: Url!], range: NSMakeRange(5, 10))

        UrlTextField.attributedText = attributedString
        UrlTextField.isUserInteractionEnabled = true
        UrlTextField.isEditable = false

        // Set how links should appear: blue and underlined
        UrlTextField.linkTextAttributes = [
            .foregroundColor: UIColor.blue,
            .underlineStyle: NSUnderlineStyle.single.rawValue
        ]
    }


}

