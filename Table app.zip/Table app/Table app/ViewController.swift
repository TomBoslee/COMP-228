//
//  ViewController.swift
//  Table app
//
//  Created by Carruthers, Thomas on 15/10/2021.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let MyCell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "myCell")
        let Names = ["Thomas","Tom","Dylan","Kyle"]
        MyCell.textLabel!.text = Names[indexPath.row]
        return MyCell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

