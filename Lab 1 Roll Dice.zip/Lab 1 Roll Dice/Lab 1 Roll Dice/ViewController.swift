//
//  ViewController.swift
//  Lab 1 Roll Dice
//
//  Created by Carruthers, Thomas on 08/10/2021.
//

import UIKit

class ViewController: UIViewController {

    
    @IBAction func GuessButton(_ sender: Any) {
        let Guess:Int = Int(InputBox.text!)!
        let DiceRoll = Int.random(in:2..<13)
        InputBox.resignFirstResponder()
        if Guess == DiceRoll {
            ResultMessage.text = "Your Guess is Right"
        }
        else{
            ResultMessage.text = "Your Guess is Wrong"
        }
    }
    @IBOutlet weak var ResultMessage: UILabel!
    
    @IBOutlet weak var InputBox: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

