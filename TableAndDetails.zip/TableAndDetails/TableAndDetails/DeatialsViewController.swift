//
//  DeatialsViewController.swift
//  TableAndDetails
//
//  Created by Carruthers, Thomas on 22/10/2021.
//

import UIKit

class DeatialsViewController: UIViewController {
    var Name = ""
    var Room = ""
    var Email = ""
    

    @IBOutlet weak var NameLabel: UILabel!
    
    
    
    @IBOutlet weak var RoomLabel: UILabel!
    
    
    @IBOutlet weak var EmailLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NameLabel.text = Name
        RoomLabel.text = Room
        EmailLabel.text = Email
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
