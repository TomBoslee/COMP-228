//
//  ViewController.swift
//  Artworks On Campus
//
//  Created by Carruthers, Thomas on 26/11/2021.
//

import UIKit
import MapKit
import CoreLocation

extension UIImageView {
    func load(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
}

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MKMapViewDelegate,
                      CLLocationManagerDelegate {
    
    var locationManager = CLLocationManager()
    var reports:ArtworkOnCampusReports? = nil
    var firstRun = true
    var startTrackingTheUser = false
    var Buildings = [String]()
    
    var locationsDict = [String: [ArtworkReport]]()
    
    @IBOutlet weak var myMap: MKMapView!
    
    @IBOutlet weak var myTable: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //Decodes the indexfile
        if let url = URL(string: "https://cgi.csc.liv.ac.uk/~phil/Teaching/COMP228/artworksOnCampus/data.php?class=campusart") {
            let session = URLSession.shared
            session.dataTask(with: url) { (data, response, err) in
                guard let jsonData = data else {
                    return
                }
                do {
                    let decoder = JSONDecoder()
                    let reportList = try decoder.decode(ArtworkOnCampusReports.self, from: jsonData)
                    self.reports = reportList
                    //creates location dictionary
                    self.groupArtworks()
                    
                    DispatchQueue.main.async {
                        self.updateTheTable()
                    }
                } catch let jsonErr {
                    print("Error decoding JSON", jsonErr)
                }
            }.resume()
        }
        
        //To get location of user at start to update
        locationManager.delegate = self as CLLocationManagerDelegate
        locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        myMap.showsUserLocation = true
        
    }
    //updates table
    func updateTheTable(){
        myTable.reloadData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return locationsDict.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        //aadds buildings into array
        for value in 0...(reports?.campusart.count)! - 1 {
            if !(Buildings.contains(reports?.campusart[value].location ?? "Unkown Building")) {
                Buildings.append(reports?.campusart[value].location ?? "Unknown Building")
            }
        }
        //Building names set as titles
        let message = "\(Buildings[section])"
        return message
    }
    
    
    func groupArtworks() {
        let allArtworks: [ArtworkReport] = reports?.campusart ?? []
        //goes through all artworks
        for art in allArtworks {
            
            var currentArtList: [ArtworkReport] = locationsDict[art.location!] ?? []
            //make sure it cannot be empty
            if currentArtList.isEmpty {
                locationsDict[art.location!] = [art]
            } else {
                //add artwork to appropriate building
                currentArtList.append(art)
                locationsDict[art.location!] = currentArtList
            }
            
            
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return locationsDict[Buildings[section]]!.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! ArtworkTableViewCell
        //set building
        let BuildingName = Buildings[indexPath.section]
        //get array of artwork
        let theArtworks = locationsDict[BuildingName]
        //the art for specifif user.
        let TheArt = theArtworks![indexPath.row]
        cell.textLabel?.text = TheArt.title
        cell.detailTextLabel?.text = TheArt.artist
        let link = TheArt.thumbnail
        cell.ArtworkImageView.load(url: link!)
        return cell
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        //get location
        let locationOfUser = locations[0]
        let latitude = locationOfUser.coordinate.latitude
        let longitude = locationOfUser.coordinate.longitude
        let location = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        
        if firstRun {
            firstRun = false
            let latDelta: CLLocationDegrees = 0.0025
            let lonDelta: CLLocationDegrees = 0.0025
            let span = MKCoordinateSpan(latitudeDelta: latDelta, longitudeDelta: lonDelta)
            let region = MKCoordinateRegion(center: location, span: span)
            self.myMap.setRegion(region, animated: true)
            
            //the following code is to prevent a bug which affects the zooming of the map to the user's location.
            //We have to leave a little time after our initial setting of the map's location and span,
            //before we can start centering on the user's location, otherwise the map never zooms in because the
            //intial zoom level and span are applied to the setCenter() method call, rather than our "requested"
            //ones, once they have taken effect on the map.
            //we setup a timer to set our boolean to true in 5 seconds.
            _ = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(startUserTracking),
                                     userInfo: nil, repeats: false)
        }
        if startTrackingTheUser == true {
            myMap.setCenter(location, animated: true)
        }
    }
    
    //this method sets the startTrackingTheUser boolean class property to true. Once it's true, subsequent calls
    //to didUpdateLocations will cause the map to center on the user's location.
    @objc func startUserTracking() {
        startTrackingTheUser = true
    }
}

