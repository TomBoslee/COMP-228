//
//  ViewController.swift
//  Assignment1MasterMind
//
//  Created by Carruthers, Thomas on 29/10/2021.
//

import UIKit
var rows = 0

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as! MastermindTableViewCell
        cell.ImageView1.image=UIImage(named: "red")
        cell.ImageView2.image=UIImage(named: "green")
        cell.ImageView3.image=UIImage(named: "orange")
        cell.ImageView4.image=UIImage(named: "yellow")
        cell.ImageView5.image=UIImage(named: "black blob")
        cell.ImageView8.image=UIImage(named: "black blob")
        cell.ImageView7.image=UIImage(named: "white blob")
        return cell
    }
    
    @IBAction func ImageButton1(_ sender: Any) {
    }
    
    @IBAction func ImageButton2(_ sender: Any) {
    }
    
    @IBAction func ImageButton3(_ sender: Any) {
    }
    
    @IBAction func ImageButton4(_ sender: Any) {
    }
    
    @IBAction func ImageButton5(_ sender: Any) {
    }
    
    @IBAction func ImageButton6(_ sender: Any) {
    }
    
    @IBAction func DeleteButton(_ sender: Any) {
    }
    
    @IBAction func OkButton(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    

}

