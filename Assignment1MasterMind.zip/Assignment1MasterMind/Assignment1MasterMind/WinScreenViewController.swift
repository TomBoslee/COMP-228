//
//  WinScreenViewController.swift
//  Assignment1MasterMind
//
//  Created by Carruthers, Thomas on 09/11/2021.
//

import UIKit

class WinScreenViewController: UIViewController {
    var Victory = false
    var Solution = [String]()
    var PScore = 0
    var CMScore = 0
    
    
    @IBOutlet weak var VictoryStatusLabel: UILabel!
    
    @IBOutlet weak var CodeMasterScore: UILabel!
    
    @IBOutlet weak var PlayerScore: UILabel!
    
    @IBOutlet weak var ImageView1: UIImageView!
    
    @IBOutlet weak var ImageView2: UIImageView!
    
    @IBOutlet weak var ImageView3: UIImageView!
    
    @IBOutlet weak var ImageView4: UIImageView!
    
    
    @IBAction func PlayAgainButton(_ sender: Any) {
    }
    
    @IBAction func QuitButton(_ sender: Any) {
        exit(0)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ImageView1.image = UIImage(named: Solution[0])
        ImageView2.image = UIImage(named: Solution[1])
        ImageView3.image = UIImage(named: Solution[2])
        ImageView4.image = UIImage(named: Solution[3])
        if (Victory){
            VictoryStatusLabel.text = "YOU WIN"
        }
        else{
            VictoryStatusLabel.text = "YOU LOSE"
        }
        PlayerScore.text = "Player: " + String(PScore)
        CodeMasterScore.text = "Code Master: " + String(CMScore)
        
        // Do any additional setup after loading the view.
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
