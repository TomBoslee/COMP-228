//
//  MastermindTableViewCell.swift
//  Assignment1MasterMind
//
//  Created by Carruthers, Thomas on 29/10/2021.
//

import UIKit

class MastermindTableViewCell: UITableViewCell {
    //Class for inside the table view to allow editing to it.
    @IBOutlet weak var ImageView1: UIImageView!
    
    @IBOutlet weak var ImageView2: UIImageView!
    
    @IBOutlet weak var ImageView3: UIImageView!
    
    @IBOutlet weak var ImageView4: UIImageView!
    
    @IBOutlet weak var ImageView5: UIImageView!
    
    @IBOutlet weak var ImageView6: UIImageView!
    
    @IBOutlet weak var ImageView7: UIImageView!
    
    @IBOutlet weak var ImageView8: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
