//
//  ViewController.swift
//  Assignment1MasterMind
//
//  Created by Carruthers, Thomas on 29/10/2021.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var Guesses = 1
    var CurrentRound = [String]()
    var GameRound = [[String]]()
    var Solution = [String]()
    var Victory = false
    var ExactMatchCount = 0
    var PartialMatchCount = 0
    var WinCount = 0
    var LoseCount = 0
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        /*Make screen show amount of rows of the array per guesses + 1 to allow for the current guess to show */
        return Guesses
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as! MastermindTableViewCell
        var Round = [String]()
        //When building table it shows current round user choices.
        if (indexPath.row == GameRound.count){
            //Reseting all images in cell
            cell.ImageView1.image = nil
            cell.ImageView2.image = nil
            cell.ImageView3.image = nil
            cell.ImageView4.image = nil
            cell.ImageView5.image = nil
            cell.ImageView6.image = nil
            cell.ImageView7.image = nil
            cell.ImageView8.image = nil
            //allows disc to appear if they are inputted by the user for the current round.
            if (CurrentRound.count > 0){
                cell.ImageView1.image=UIImage(named: CurrentRound[0])
            }
            if (CurrentRound.count > 1){
                cell.ImageView2.image=UIImage(named: CurrentRound[1])
            }
            if (CurrentRound.count > 2){
                cell.ImageView3.image=UIImage(named: CurrentRound[2])
            }
            if (CurrentRound.count > 3){
                cell.ImageView4.image=UIImage(named: CurrentRound[3])
            }
        }
        //Inputs for all the previous rounds
        else if (GameRound.count > 0){
            //Get the array of the players choices from the arrays it can select from.
            Round = GameRound[indexPath.row]
            cell.ImageView1.image=UIImage(named: Round[0])
            cell.ImageView2.image=UIImage(named: Round[1])
            cell.ImageView3.image=UIImage(named: Round[2])
            cell.ImageView4.image=UIImage(named: Round[3])
            cell.ImageView5.image=UIImage(named: Round[4])
            cell.ImageView6.image=UIImage(named: Round[5])
            cell.ImageView7.image=UIImage(named: Round[6])
            cell.ImageView8.image=UIImage(named: Round[7])
        }
        return cell
    }
    //As long as less than 4 allow user to add a colour depending on what they click
    @IBAction func ImageButton1(_ sender: Any) {
        if (CurrentRound.count < 4){
            CurrentRound.append("blue")
            TableView.reloadData()

        }
    }
    
    @IBAction func ImageButton2(_ sender: Any) {
        if (CurrentRound.count < 4){
            CurrentRound.append("yellow")
            TableView.reloadData()

        }
    }
    
    @IBAction func ImageButton3(_ sender: Any) {
        if (CurrentRound.count < 4){
            CurrentRound.append("green")
            TableView.reloadData()

        }
    }
    
    @IBAction func ImageButton4(_ sender: Any) {
        if (CurrentRound.count < 4){
            CurrentRound.append("red")
            TableView.reloadData()

        }
    }
    
    @IBAction func ImageButton5(_ sender: Any) {
        if (CurrentRound.count < 4){
            CurrentRound.append("grey")
            TableView.reloadData()

        }
    }
    
    @IBAction func ImageButton6(_ sender: Any) {
        if (CurrentRound.count < 4){
            CurrentRound.append("orange")
            TableView.reloadData()

        }
    }
    //As long as array is not zero remove the last inputted option from the array.
    @IBAction func DeleteButton(_ sender: Any) {
        if (CurrentRound.count > 0){
            CurrentRound.removeLast()
            TableView.reloadData()

        }
    }
    //As long as 4 options are choosen allow the player to submit choices.
    @IBAction func OkButton(_ sender: Any) {
        //Plays if choices are 4 and that the user hasnt used all 10 guesses
        if (CurrentRound.count == 4 && Guesses < 10){
            Guesses = Guesses + 1
            //reset values
            ExactMatchCount = 0
            PartialMatchCount = 0
            //Create tempoary arrays so it does not affect if change values.
            var TempSolution = Solution
            var TempGuess = CurrentRound
            //Check for exact matches from solution to players guess.
            for j in 0 ... 3 {
                if (TempSolution[j] == TempGuess[j]) {
                    ExactMatchCount += 1
                    //if match change so it cannot mach another time.
                    TempSolution[j] = "++"
                    TempGuess[j] = "==" }}
            //Check for partial matches from solution to players guess
            for j in 0 ... 3 {
                for k in 0 ... 3 {
                    if (j != k) {
                        if (TempSolution[j] == TempGuess[k]) {
                            PartialMatchCount += 1
                            //Change so it cannot match another (Helps when more of one of the same colour)
                            TempSolution[j] = "++"
                        }}}}
            //Game win condition
            if (ExactMatchCount == 4){
                WinCount = WinCount + 1
                Victory = true
                //Open win screen
                performSegue(withIdentifier: "WinScreen", sender: nil)
            }
            //adds the blobs so player is able to tell how close they were to the solution
            if (ExactMatchCount > 0){
                CurrentRound.append("black blob")
            }
            if (ExactMatchCount > 1){
                CurrentRound.append("black blob")
            }
            if (ExactMatchCount > 2){
                CurrentRound.append("black blob")
            }
            if (ExactMatchCount > 3){
                CurrentRound.append("black blob")
            }
            if (PartialMatchCount > 0) {
                CurrentRound.append("white blob")
            }
            if (PartialMatchCount > 1) {
                CurrentRound.append("white blob")
            }
            if (PartialMatchCount > 2) {
                CurrentRound.append("white blob")
            }
            if (PartialMatchCount > 3) {
                CurrentRound.append("white blob")
            }
            //Stops out of bound exceptions when array is not filled with 8 (4 player choice, 4 blob for comparison)
            while CurrentRound.count != 8 {
                CurrentRound.append("empty")
            }
            //Adds solution to array that holds all rounds
            print("The users guess is: ")
            print(CurrentRound)
            GameRound.append(CurrentRound)
            //reset the array
            CurrentRound.removeAll()
            TableView.reloadData()
        }
        //Set lose condition so if 10 guesses are done and it wrong.
        else if (Guesses == 10 && CurrentRound.count == 4){
            Victory = false
            print(Victory)
            LoseCount = LoseCount + 1
            //Move to win screen
            performSegue(withIdentifier: "WinScreen", sender: nil)
        }
    }
    
    @IBOutlet weak var TableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let Colours = ["red", "blue","orange","yellow","grey","green"]
        var num = Int()
        //randomises 4 numbers between 0 and 5 which corresponds to cloours in array for solution.
        for _ in 1...4 {
            num = Int.random(in: 0..<6)
            Solution.append(Colours[num])
        }
        print("The Solution is: ")
        print(Solution)
    }
    //Allow the extra screen to have carried over variable to change displays.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "WinScreen" {
            let secondviewcontroller = segue.destination as! WinScreenViewController
            secondviewcontroller.Victory = Victory
            secondviewcontroller.Solution = Solution
            secondviewcontroller.PScore = WinCount
            secondviewcontroller.CMScore = LoseCount
        }
    }
    
    @IBAction func unwindToInitialVC(_ unwindSegue: UIStoryboardSegue) {
        _ = unwindSegue.source
        //upon unwind of segue reset variables so user can play again.
        Guesses = 1
        Victory = false
        GameRound.removeAll()
        CurrentRound.removeAll()
        ExactMatchCount = 0
        PartialMatchCount = 0
        Solution.removeAll()
        viewDidLoad()
        TableView.reloadData()
        // Use data from the view controller which initiated the unwind segue
    }
    

}

